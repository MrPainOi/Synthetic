# CEISA PrintShare - Android App (Forward Dokumen ke Print Hub)

Aplikasi native Android khusus untuk integrasi **Android System Share Sheet** langsung ke **CEISA Print Hub & WiFi Share**.

---

## 🚀 Fitur Utama
1. **Muncul Otomatis di Menu Share Android:**
   Ketika Anda membuka dokumen PDF/Gambar di **WhatsApp**, **Telegram**, **Gmail**, atau **File Manager** dan menekan tombol **Bagikan (Share)**, ikon **CEISA PrintShare** akan muncul di daftar aplikasi.
2. **One-Tap Instant Print:**
   Tersedia opsi "Selalu cetak otomatis". Begitu dipilih di menu Share, dokumen langsung terkirim dan dicetak ke printer kantor tanpa perlu menekan tombol konfirmasi lagi!
3. **Pilihan Printer Kantor Dinamis:**
   Mengambil daftar seluruh printer Windows di PC (printer laser, dot-matrix, ink-jet, dll.) secara otomatis.
4. **Auto-Discovery Wi-Fi:**
   Tombol *Scan Wi-Fi Otomatis* dapat memindai dan menemukan IP PC Anda di jaringan lokal secara mandiri tanpa perlu repot mengetik IP manual.
5. **Forward ke CEISA Draft:**
   Dapat langsung mem-forward dokumen ke modul **CEISA Document Parser** (PIB / PEB) sehingga langsung terkonversi menjadi draft kepabeanan di PC.

---

## 🛠️ Cara Build APK di Android Studio:
1. Buka folder `c:\Synthetic\android-printshare\` menggunakan **Android Studio**.
2. Biarkan Gradle melakukan sinkronisasi dependensi.
3. Klik menu **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
4. File APK siap digunakan di `app/build/outputs/apk/debug/app-debug.apk`.
5. Kirim file APK ke HP Android Anda dan instal (izinkan *Install from unknown sources*).

---

## 📱 Cara Penggunaan:
1. Pastikan HP Android dan PC terhubung di **Wi-Fi yang sama**.
2. Buka aplikasi **CEISA PrintShare** di HP Anda sekali untuk pertama kali:
   - Tekan **Scan Wi-Fi Otomatis** (atau masukkan IP PC Anda, misal `192.168.1.15:5005`).
   - Pilih printer kantor yang ingin dijadikan default.
   - Aktifkan toggle **Mode One-Tap** jika ingin mencetak instan tanpa dialog.
3. Sekarang, buka dokumen apa saja di WhatsApp atau File Manager:
   - Tekan **Share / Bagikan**
   - Pilih **CEISA PrintShare**
   - Dokumen langsung terkirim ke printer kantor Anda!

