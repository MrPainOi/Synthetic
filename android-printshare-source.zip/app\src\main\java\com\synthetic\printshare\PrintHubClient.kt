package com.synthetic.printshare

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object PrintHubClient {

    data class ServerStatus(
        val isOnline: Boolean,
        val message: String,
        val printerCount: Int = 0,
        val queueCount: Int = 0
    )

    data class PrinterInfo(
        val name: String,
        val isDefault: Boolean
    )

    data class PrintResponse(
        val success: Boolean,
        val message: String,
        val jobId: String? = null
    )

    fun checkStatus(baseUrl: String): ServerStatus {
        return try {
            val url = URL("$baseUrl/api/print/status")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 2500
                readTimeout = 2500
                requestMethod = "GET"
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val printers = json.optJSONArray("printers")?.length() ?: 0
                val queue = json.optJSONArray("queue")?.length() ?: 0
                ServerStatus(true, "Online (${conn.responseCode})", printers, queue)
            } else {
                ServerStatus(false, "Server HTTP ${conn.responseCode}")
            }
        } catch (e: Exception) {
            ServerStatus(false, e.localizedMessage ?: "Gagal terhubung")
        }
    }

    fun getPrinters(baseUrl: String): List<PrinterInfo> {
        val list = mutableListOf<PrinterInfo>()
        try {
            val url = URL("$baseUrl/api/print/printers")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 3000
                readTimeout = 3000
                requestMethod = "GET"
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val arr = json.optJSONArray("printers") ?: JSONArray()
                val defName = json.optString("defaultPrinter", "")
                for (i in 0 until arr.length()) {
                    val p = arr.getJSONObject(i)
                    val name = p.optString("name", "")
                    val isDef = p.optBoolean("isDefault", name == defName)
                    if (name.isNotEmpty()) {
                        list.add(PrinterInfo(name, isDef))
                    }
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun sendFileToPrinter(
        baseUrl: String,
        printerName: String,
        copies: Int,
        filename: String,
        fileBytes: ByteArray
    ): PrintResponse {
        val boundary = "===Boundary" + System.currentTimeMillis() + "==="
        val lineEnd = "\r\n"
        val twoHyphens = "--"

        return try {
            val url = URL("$baseUrl/api/print/file")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 30000
                doInput = true
                doOutput = true
                useCaches = false
                requestMethod = "POST"
                setRequestProperty("Connection", "Keep-Alive")
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            DataOutputStream(conn.outputStream).use { dos ->
                // Field: printer
                dos.writeBytes("$twoHyphens$boundary$lineEnd")
                dos.writeBytes("Content-Disposition: form-data; name=\"printer\"$lineEnd$lineEnd")
                dos.writeBytes(printerName + lineEnd)

                // Field: copies
                dos.writeBytes("$twoHyphens$boundary$lineEnd")
                dos.writeBytes("Content-Disposition: form-data; name=\"copies\"$lineEnd$lineEnd")
                dos.writeBytes(copies.toString() + lineEnd)

                // Field: file
                dos.writeBytes("$twoHyphens$boundary$lineEnd")
                dos.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"$filename\"$lineEnd")
                dos.writeBytes("Content-Type: application/octet-stream$lineEnd$lineEnd")
                dos.write(fileBytes)
                dos.writeBytes(lineEnd)

                // End boundary
                dos.writeBytes("$twoHyphens$boundary$twoHyphens$lineEnd")
                dos.flush()
            }

            val code = conn.responseCode
            val responseStream = if (code in 200..299) conn.inputStream else conn.errorStream
            val respBody = responseStream?.bufferedReader()?.use { it.readText() } ?: ""

            if (code in 200..299) {
                val json = try { JSONObject(respBody) } catch (_: Exception) { JSONObject() }
                PrintResponse(
                    success = json.optBoolean("success", true),
                    message = json.optString("message", "Dokumen berhasil dikirim ke printer spooler."),
                    jobId = json.optString("jobId", null)
                )
            } else {
                PrintResponse(false, "Server Error ($code): $respBody")
            }
        } catch (e: Exception) {
            PrintResponse(false, "Koneksi Gagal: ${e.localizedMessage}")
        }
    }

    fun forwardToCeisaParser(
        baseUrl: String,
        filename: String,
        fileBytes: ByteArray,
        mode: String = "impor"
    ): PrintResponse {
        val boundary = "===CeisaParse" + System.currentTimeMillis() + "==="
        val lineEnd = "\r\n"
        val twoHyphens = "--"

        return try {
            val url = URL("$baseUrl/api/parse-documents?mode=$mode")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 60000
                doInput = true
                doOutput = true
                useCaches = false
                requestMethod = "POST"
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            DataOutputStream(conn.outputStream).use { dos ->
                dos.writeBytes("$twoHyphens$boundary$lineEnd")
                dos.writeBytes("Content-Disposition: form-data; name=\"files\"; filename=\"$filename\"$lineEnd")
                dos.writeBytes("Content-Type: application/pdf$lineEnd$lineEnd")
                dos.write(fileBytes)
                dos.writeBytes(lineEnd)
                dos.writeBytes("$twoHyphens$boundary$twoHyphens$lineEnd")
                dos.flush()
            }

            val code = conn.responseCode
            val responseStream = if (code in 200..299) conn.inputStream else conn.errorStream
            val respBody = responseStream?.bufferedReader()?.use { it.readText() } ?: ""

            if (code in 200..299) {
                PrintResponse(true, "Dokumen berhasil dikirim & diekstrak ke CEISA draft!")
            } else {
                PrintResponse(false, "Parser gagal ($code): $respBody")
            }
        } catch (e: Exception) {
            PrintResponse(false, "Gagal upload ke parser: ${e.localizedMessage}")
        }
    }

    /**
     * Fast Wi-Fi Subnet Scanner to auto-discover PC server on port 5005
     */
    fun autoDiscoverServer(context: Context, onFound: (String) -> Unit) {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return
        val ipInt = wm.connectionInfo?.ipAddress ?: return
        if (ipInt == 0) return

        val myIp = String.format(
            "%d.%d.%d.%d",
            ipInt and 0xff,
            ipInt shr 8 and 0xff,
            ipInt shr 16 and 0xff,
            ipInt shr 24 and 0xff
        )
        val subnet = myIp.substringBeforeLast(".")

        val executor = Executors.newFixedThreadPool(32)
        val found = AtomicBoolean(false)

        for (i in 1..254) {
            val targetIp = "$subnet.$i"
            executor.execute {
                if (found.get()) return@execute
                try {
                    val url = URL("http://$targetIp:5005/api/status")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 600
                        readTimeout = 600
                        requestMethod = "GET"
                    }
                    if (conn.responseCode == 200) {
                        if (found.compareAndSet(false, true)) {
                            onFound(targetIp)
                        }
                    }
                    conn.disconnect()
                } catch (_: Exception) {}
            }
        }

        executor.shutdown()
        executor.awaitTermination(3, TimeUnit.SECONDS)
    }
}

