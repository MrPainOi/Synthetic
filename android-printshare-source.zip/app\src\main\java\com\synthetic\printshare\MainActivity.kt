package com.synthetic.printshare

import android.app.Activity
import android.os.Bundle
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var settings: SettingsManager
    private val printersList = mutableListOf<PrintHubClient.PrinterInfo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settings = SettingsManager(this)
        initViews()
    }

    private fun initViews() {
        val etHost = findViewById<EditText>(R.id.etServerHost)
        val etPort = findViewById<EditText>(R.id.etServerPort)
        val btnScan = findViewById<Button>(R.id.btnScanWifi)
        val btnTest = findViewById<Button>(R.id.btnTestConn)
        val tvStatus = findViewById<TextView>(R.id.tvMainStatus)
        val spnPrinters = findViewById<Spinner>(R.id.spnMainPrinters)
        val swOneTap = findViewById<Switch>(R.id.swOneTap)

        etHost.setText(settings.serverHost)
        etPort.setText(settings.serverPort.toString())
        swOneTap.isChecked = settings.isOneTapAutoPrint

        swOneTap.setOnCheckedChangeListener { _, isChecked ->
            settings.isOneTapAutoPrint = isChecked
            val msg = if (isChecked) "Mode One-Tap aktif: Share langsung mencetak." else "Mode dialog konfirmasi aktif."
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }

        fun saveHostPort() {
            val host = etHost.text.toString().trim()
            val port = etPort.text.toString().trim().toIntOrNull() ?: 5005
            if (host.isNotEmpty()) {
                settings.serverHost = host
                settings.serverPort = port
            }
        }

        btnTest.setOnClickListener {
            saveHostPort()
            tvStatus.text = "Menguji koneksi ke ${settings.baseUrl}..."
            tvStatus.setTextColor(getColor(R.color.text_secondary))

            thread {
                val status = PrintHubClient.checkStatus(settings.baseUrl)
                val printers = PrintHubClient.getPrinters(settings.baseUrl)
                printersList.clear()
                printersList.addAll(printers)

                runOnUiThread {
                    if (status.isOnline) {
                        tvStatus.text = "✓ Terhubung! Terdeteksi ${printers.size} printer Windows di PC."
                        tvStatus.setTextColor(getColor(R.color.success))
                    } else {
                        tvStatus.text = "⚠️ Gagal: ${status.message}\nPastikan PC dan HP di Wi-Fi yang sama dan START_SERVER.bat sudah berjalan."
                        tvStatus.setTextColor(getColor(R.color.error))
                    }

                    if (printers.isNotEmpty()) {
                        val names = printers.map { if (it.isDefault) "${it.name} ★ (Default)" else it.name }
                        spnPrinters.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
                        val defIdx = printers.indexOfFirst { it.name == settings.defaultPrinter || it.isDefault }
                        if (defIdx != -1) spnPrinters.setSelection(defIdx)
                    }
                }
            }
        }

        btnScan.setOnClickListener {
            btnScan.isEnabled = false
            btnScan.text = "Scanning Wi-Fi..."
            tvStatus.text = "Memindai seluruh IP di Wi-Fi lokal mencari port 5005..."
            tvStatus.setTextColor(getColor(R.color.text_secondary))

            thread {
                PrintHubClient.autoDiscoverServer(this) { foundIp ->
                    runOnUiThread {
                        etHost.setText(foundIp)
                        saveHostPort()
                        btnScan.isEnabled = true
                        btnScan.text = "Scan Wi-Fi Otomatis"
                        Toast.makeText(this, "✓ Server ditemukan di $foundIp!", Toast.LENGTH_LONG).show()
                        btnTest.performClick()
                    }
                }

                runOnUiThread {
                    btnScan.postDelayed({
                        if (btnScan.text == "Scanning Wi-Fi...") {
                            btnScan.isEnabled = true
                            btnScan.text = "Scan Wi-Fi Otomatis"
                        }
                    }, 4000)
                }
            }
        }

        spnPrinters.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (position in printersList.indices) {
                    settings.defaultPrinter = printersList[position].name
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Auto test on initial open
        btnTest.performClick()
    }

    override fun onPause() {
        super.onPause()
        val etHost = findViewById<EditText>(R.id.etServerHost)
        val etPort = findViewById<EditText>(R.id.etServerPort)
        val host = etHost.text.toString().trim()
        val port = etPort.text.toString().trim().toIntOrNull() ?: 5005
        if (host.isNotEmpty()) {
            settings.serverHost = host
            settings.serverPort = port
        }
    }
}

