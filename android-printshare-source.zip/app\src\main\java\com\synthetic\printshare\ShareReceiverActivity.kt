package com.synthetic.printshare

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.*
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlin.concurrent.thread

class ShareReceiverActivity : Activity() {

    private lateinit var settings: SettingsManager
    private var sharedUri: Uri? = null
    private var sharedFileName: String = "dokumen.pdf"
    private var sharedFileSize: Long = 0
    private var fileBytes: ByteArray? = null

    private var availablePrinters = mutableListOf<PrintHubClient.PrinterInfo>()
    private var copies = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsManager(this)

        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) {
            finish()
            return
        }

        when (intent.action) {
            Intent.ACTION_SEND -> {
                sharedUri = intent.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val list = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                if (!list.isNullOrEmpty()) {
                    sharedUri = list[0] // take first file or loop
                }
            }
        }

        if (sharedUri == null) {
            Toast.makeText(this, "Tidak ada berkas yang dibagikan.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        resolveFileInfo(sharedUri!!)

        // ONE-TAP AUTO PRINT MODE: If user previously opted into instant printing and printer is configured
        if (settings.isOneTapAutoPrint && settings.defaultPrinter.isNotEmpty()) {
            performInstantPrint()
            return
        }

        // Show UI Confirmation Dialog
        setContentView(R.layout.activity_share_receiver)
        initDialogViews()
    }

    private fun resolveFileInfo(uri: Uri) {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx != -1) sharedFileName = cursor.getString(nameIdx) ?: "dokumen.pdf"
                    if (sizeIdx != -1) sharedFileSize = cursor.getLong(sizeIdx)
                }
            }

            // Read bytes
            contentResolver.openInputStream(uri)?.use { input ->
                fileBytes = input.readBytes()
                if (sharedFileSize == 0L && fileBytes != null) {
                    sharedFileSize = fileBytes!!.size.toLong()
                }
            }
        } catch (e: Exception) {
            sharedFileName = uri.lastPathSegment ?: "dokumen.pdf"
        }
    }

    private fun performInstantPrint() {
        val printer = settings.defaultPrinter
        Toast.makeText(this, "Mengirim \"$sharedFileName\" ke $printer...", Toast.LENGTH_SHORT).show()

        thread {
            val bytes = fileBytes ?: contentResolver.openInputStream(sharedUri!!)?.readBytes()
            if (bytes == null) {
                runOnUiThread {
                    Toast.makeText(this, "Gagal membaca berkas.", Toast.LENGTH_SHORT).show()
                    finish()
                }
                return@thread
            }

            val resp = PrintHubClient.sendFileToPrinter(
                baseUrl = settings.baseUrl,
                printerName = printer,
                copies = settings.defaultCopies,
                filename = sharedFileName,
                fileBytes = bytes
            )

            runOnUiThread {
                if (resp.success) {
                    Toast.makeText(this, "✓ Berhasil dicetak di $printer!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Gagal: ${resp.message}", Toast.LENGTH_LONG).show()
                }
                finishAndRemoveTask()
            }
        }
    }

    private fun initDialogViews() {
        val tvFileName = findViewById<TextView>(R.id.tvFileName)
        val tvFileSize = findViewById<TextView>(R.id.tvFileSize)
        val tvServerBadge = findViewById<TextView>(R.id.tvServerBadge)
        val spnPrinters = findViewById<Spinner>(R.id.spnPrinters)
        val tvCopies = findViewById<TextView>(R.id.tvCopies)
        val btnMinus = findViewById<Button>(R.id.btnMinusCopies)
        val btnPlus = findViewById<Button>(R.id.btnPlusCopies)
        val btnPrint = findViewById<Button>(R.id.btnSubmitPrint)
        val btnParser = findViewById<Button>(R.id.btnForwardParser)
        val cbOneTap = findViewById<CheckBox>(R.id.cbOneTap)
        val btnClose = findViewById<ImageButton>(R.id.btnClose)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        tvFileName.text = sharedFileName
        tvFileSize.text = formatFileSize(sharedFileSize)
        cbOneTap.isChecked = settings.isOneTapAutoPrint
        copies = settings.defaultCopies
        tvCopies.text = copies.toString()

        btnClose.setOnClickListener { finish() }

        btnMinus.setOnClickListener {
            if (copies > 1) {
                copies--
                tvCopies.text = copies.toString()
            }
        }
        btnPlus.setOnClickListener {
            copies++
            tvCopies.text = copies.toString()
        }

        // Fetch server status & printers in background
        tvServerBadge.text = "Menghubungi ${settings.baseUrl}..."
        thread {
            val status = PrintHubClient.checkStatus(settings.baseUrl)
            val printers = PrintHubClient.getPrinters(settings.baseUrl)
            availablePrinters.clear()
            availablePrinters.addAll(printers)

            runOnUiThread {
                if (status.isOnline) {
                    tvServerBadge.text = "● Online: ${settings.baseUrl}"
                    tvServerBadge.setTextColor(getColor(R.color.success))
                } else {
                    tvServerBadge.text = "⚠️ Offline: ${status.message}"
                    tvServerBadge.setTextColor(getColor(R.color.warning))
                }

                if (printers.isNotEmpty()) {
                    val names = printers.map { if (it.isDefault) "${it.name} ★ (Default)" else it.name }
                    val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
                    spnPrinters.adapter = adapter

                    val defIdx = printers.indexOfFirst { it.name == settings.defaultPrinter || it.isDefault }
                    if (defIdx != -1) spnPrinters.setSelection(defIdx)
                } else {
                    spnPrinters.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Tidak ada printer terdeteksi"))
                }
            }
        }

        // Action Print
        btnPrint.setOnClickListener {
            if (availablePrinters.isEmpty()) {
                Toast.makeText(this, "Printer belum tersedia. Periksa koneksi PC.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedIdx = spnPrinters.selectedItemPosition
            val selectedPrinter = if (selectedIdx in availablePrinters.indices) availablePrinters[selectedIdx].name else settings.defaultPrinter
            if (selectedPrinter.isEmpty()) {
                Toast.makeText(this, "Silakan pilih printer.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (cbOneTap.isChecked) {
                settings.isOneTapAutoPrint = true
                settings.defaultPrinter = selectedPrinter
            }

            progressBar.visibility = View.VISIBLE
            btnPrint.isEnabled = false
            btnParser.isEnabled = false

            thread {
                val bytes = fileBytes ?: contentResolver.openInputStream(sharedUri!!)?.readBytes() ?: ByteArray(0)
                val resp = PrintHubClient.sendFileToPrinter(
                    baseUrl = settings.baseUrl,
                    printerName = selectedPrinter,
                    copies = copies,
                    filename = sharedFileName,
                    fileBytes = bytes
                )

                runOnUiThread {
                    progressBar.visibility = View.GONE
                    if (resp.success) {
                        Toast.makeText(this, "✓ Berhasil dikirim ke $selectedPrinter!", Toast.LENGTH_LONG).show()
                        finish()
                    } else {
                        btnPrint.isEnabled = true
                        btnParser.isEnabled = true
                        Toast.makeText(this, "Gagal: ${resp.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        // Action Forward to CEISA Parser
        btnParser.setOnClickListener {
            progressBar.visibility = View.VISIBLE
            btnPrint.isEnabled = false
            btnParser.isEnabled = false

            thread {
                val bytes = fileBytes ?: contentResolver.openInputStream(sharedUri!!)?.readBytes() ?: ByteArray(0)
                val resp = PrintHubClient.forwardToCeisaParser(
                    baseUrl = settings.baseUrl,
                    filename = sharedFileName,
                    fileBytes = bytes,
                    mode = "impor"
                )

                runOnUiThread {
                    progressBar.visibility = View.GONE
                    if (resp.success) {
                        Toast.makeText(this, "✓ Dokumen terkirim ke CEISA Draft!", Toast.LENGTH_LONG).show()
                        finish()
                    } else {
                        btnPrint.isEnabled = true
                        btnParser.isEnabled = true
                        Toast.makeText(this, "Gagal: ${resp.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb > 1024) String.format("%.2f MB", kb / 1024.0) else String.format("%.1f KB", kb)
    }
}

