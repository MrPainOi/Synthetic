package com.synthetic.printshare

import android.content.Context
import android.content.SharedPreferences

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ceisa_printshare_prefs", Context.MODE_PRIVATE)

    var serverHost: String
        get() = prefs.getString("server_host", "192.168.1.15") ?: "192.168.1.15"
        set(value) = prefs.edit().putString("server_host", cleanHost(value)).apply()

    var serverPort: Int
        get() = prefs.getInt("server_port", 5005)
        set(value) = prefs.edit().putInt("server_port", value).apply()

    var defaultPrinter: String
        get() = prefs.getString("default_printer", "") ?: ""
        set(value) = prefs.edit().putString("default_printer", value).apply()

    var isOneTapAutoPrint: Boolean
        get() = prefs.getBoolean("one_tap_auto_print", false)
        set(value) = prefs.edit().putBoolean("one_tap_auto_print", value).apply()

    var defaultCopies: Int
        get() = prefs.getInt("default_copies", 1)
        set(value) = prefs.edit().putInt("default_copies", value).apply()

    val baseUrl: String
        get() {
            val host = serverHost.trim()
            val port = serverPort
            return if (host.startsWith("http://") || host.startsWith("https://")) {
                if (host.contains(":$port")) host else "$host:$port"
            } else {
                "http://$host:$port"
            }
        }

    private fun cleanHost(raw: String): String {
        return raw.trim()
            .removePrefix("http://")
            .removePrefix("https://")
            .split(":")[0]
            .trim()
    }
}

