globalThis.__CEISA_MODULE_MODE__ = 'autoinput';
